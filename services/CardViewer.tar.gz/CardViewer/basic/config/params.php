<?php

return [
    'adminEmail' => 'admin@example.com',
    'max_password_lenght' => '4'
];
