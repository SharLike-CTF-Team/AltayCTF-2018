<?php

/* @var $this \yii\web\View */

/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\helpers\Url;
use yii\widgets\Breadcrumbs;
//use app\assets\AppAsset;
//
//AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<?php $this->beginBody() ?>
            <?= $content ?>
<?php $this->endBody() ?>
<?php $this->endPage() ?>
