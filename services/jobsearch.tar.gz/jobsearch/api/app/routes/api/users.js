var mongoose = require('mongoose');
var sanitize = require('mongo-sanitize');
var router = require('express').Router();
var passport = require('passport');
var User = mongoose.model('User');
var auth = require('../auth');

router.get('/user', auth.required, function(req, res, next) {
    User.findById(req.payload.id).then(function (user) {
        if (!user) { 
            return res.sendStatus(401); 
        }

        return res.json({ user: user.toJSON() });
    }).catch(next);
});

router.post('/signin', function(req, res, next) {
    if (!req.body.user.email) {
        return res.status(422).json({success: false, message: 'E-mail не может быть пустым'});
    }
    if (!req.body.user.password) {
        return res.status(422).json({success: false, message: 'Пароль не может быть пустым'});
    }

    passport.authenticate('local', {session: false}, function(err, user, info) {
        if (err) {
            return next(err);
        }

        if (user) {
            user.token = user.generateJWT();
            return res.json({success: true, user: user.toAuthJSON()});
        } else {
            return res.status(422).json(info);
        }
    })(req, res, next);
});

router.put('/signup', function(req, res, next) {
    var user = new User();

    user.email = sanitize(req.body.user.email);
    User.find({email: user.email}).then(function (users) {
        if (users.length > 0) {
            return res.json({
                'success': false,
                'message': 'Пользователь с таким email уже существует'
            });
        }
        user.setPassword(sanitize(req.body.user.password));
        user.type = 'employer' === req.body.user.type ? 'employer' : 'applicant';
        user.name = sanitize(req.body.user.name);
        user.phone = sanitize(req.body.user.phone);

        user.save().then(function() {
            return res.json({
                'success': true,
                'message': 'Регистрация прошла успешно'
            });
        }).catch(function(err) {
            return res.json({
                'success': false,
                'message': 'Заполнены не все поля'
            });
        });
    }).catch(next);
});

module.exports = router;