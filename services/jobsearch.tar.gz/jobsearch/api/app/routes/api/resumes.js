var router = require('express').Router();
var mongoose = require('mongoose');
var sanitize = require('mongo-sanitize');
var Resume = mongoose.model('Resume');
var User = mongoose.model('User');
var auth = require('../auth');

router.post('/list', function(req, res) {
    var access = req.body.access;
    var limit = parseInt(req.body.limit) | 10;
    if (access === 'premium') {
        return res.json({
            success: false,
            message: 'Премиум-резюме недоступны!'
        });
    }
    Resume.find({access: access}).limit(limit).exec(function(err, resumes) {
        if (err) {
            return res.json({
                success: false,
                message: 'Произошла внутренняя ошибка'
            })
        }
        if (!resumes.length) {
            return res.json({
                success: false,
                message: 'Не найдено ни одного резюме'
            });
        }

        return res.json({
            success: true,
            data: resumes
        })
    })
});

router.get('/list/my', auth.required, function(req, res, next) {
    User.findById(req.payload.id).then(function (user) {
        if (!user) { 
            return res.sendStatus(401); 
        }
        Resume.find({user: user._id}, function(err, resumes) {
            if (err) {
                return res.json({
                    success: false,
                    message: 'Произошла внутрення ошибка'
                })
            }
            if (!resumes.length) {
                return res.json({
                    success: false,
                    message: 'Не найдено ни одного резюме'
                });
            }
    
            return res.json({
                success: true,
                data: resumes
            })
        })
    }).catch(next);
});

router.put('/create', auth.required, function(req, res, next) {
    User.findById(req.payload.id).then(function (user) {
        if (!user) { 
            return res.sendStatus(401); 
        }
        resume = new Resume({
            position: sanitize(req.body.position),
            salary: parseInt(req.body.salary) | 0,
            experience: sanitize(req.body.experience),
            skills: sanitize(req.body.skills),
            education: sanitize(req.body.education),
            about_me: sanitize(req.body.about_me),
            access: sanitize(req.body.access),
            user: user._id
        })
        resume.save(function(err) {
            if (err) {
                return res.json({
                    success: false, 
                    message: 'Произошла внутренняя ошибка'
                });
            }
            return res.json({
                success: true, 
                message: 'Резюме успешно создано'
            });
        })
    }).catch(next);
});

module.exports = router;