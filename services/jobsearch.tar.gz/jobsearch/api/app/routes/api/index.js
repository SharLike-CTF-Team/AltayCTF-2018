var router = require('express').Router();

router.use('/', require('./users'));
router.use('/vacancies', require('./vacancies'));
router.use('/resumes', require('./resumes'));
router.use('/search', require('./search'));

module.exports = router;