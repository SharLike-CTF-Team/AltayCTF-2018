var router = require('express').Router();
var mongoose = require('mongoose');
var sanitize = require('mongo-sanitize');
var Vacancy = mongoose.model('Vacancy');
var Resume = mongoose.model('Resume');

router.post('/', function(req, res) {
    var query = sanitize(req.body.query);
    var type = sanitize(req.body.type);

    if ('resumes' === type) {
        Resume.find({
            $text: {$search: query},
            access: 'free'
        }, function(err, resumes) {
            if (err) {
                return res.json({
                    success: false,
                    message: 'Произошла внутренняя ошибка'
                });
            }
            if (!resumes.length) {
                return res.json({
                    success: false,
                    message: 'Не найдено ни одного резюме'
                });
            }

            return res.json({
                success: true,
                data: resumes
            });
        })
    } else if ('vacancies' === type) {
        Vacancy.find({
            $text: {$search: query},
            archived: req.body.archived
        }, function(err, vacancies) {
            if (err) {
                return res.json({
                    success: false,
                    message: 'Произошла внутренняя ошибка'
                });
            }

            if (!vacancies.length) {
                return res.json({
                    success: false,
                    message: 'Не найдено ни одной вакансии'
                });
            }

            return res.json({
                success: true,
                data: vacancies
            });
        })
    } else {
        return res.json({
            success: false,
            message: 'Произошла внутренняя ошибка'
        });
    }
});

module.exports = router;