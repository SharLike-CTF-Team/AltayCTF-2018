var router = require('express').Router();
var mongoose = require('mongoose');
var sanitize = require('mongo-sanitize');
var Vacancy = mongoose.model('Vacancy');
var User = mongoose.model('User');
var auth = require('../auth');

router.get('/list', function(req, res, next) {
    Vacancy.find({archived: false}, function(err, vacancies) {
        if (err) {
            return res.json({
                success: false,
                message: 'Произошла внутрення ошибка'
            })
        }
        if (!vacancies.length) {
            return res.json({
                success: false,
                message: 'Не найдено ни одной вакансии'
            });
        }
        return res.json({
            success: true,
            data: vacancies
        })
    })
});

router.get('/list/my', auth.required, function(req, res, next) {
    User.findById(req.payload.id).then(function (user) {
        if (!user) { 
            return res.sendStatus(401); 
        }
        
        Vacancy.find({user: user._id}, function(err, vacancies) {
            if (err) {
                return res.json({
                    success: false,
                    message: 'Произошла внутрення ошибка'
                })
            }
            if (!vacancies.length) {
                return res.json({
                    success: false,
                    message: 'Не найдено ни одной вакансии'
                });
            }
            return res.json({
                success: true,
                data: vacancies
            })
        });
    }).catch(next);
});

router.put('/create', auth.required, function(req, res, next) {
    User.findById(req.payload.id).then(function (user) {
        if (!user) { 
            return res.sendStatus(401); 
        }

        var title = sanitize(req.body.title);
        var description = sanitize(req.body.description);
        var skills = sanitize(req.body.skills);

        vacancy = new Vacancy({
            title: title,
            description: description,
            required_skills: skills,
            archived: req.body.archived | false,
            user: user._id
        })
        vacancy.save(function(err) {
            if (err) {
                return res.json({
                    success: false, 
                    message: 'Произошла ошибка при создании вакансии'
                });
            }
            return res.json({
                success: true, 
                message: 'Вакансия успешно создана'
            });
        })
        
    }).catch(next);
});

module.exports = router;