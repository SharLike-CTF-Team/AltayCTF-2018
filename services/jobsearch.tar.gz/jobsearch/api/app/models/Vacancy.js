var mongoose = require('mongoose');

var VacancySchema = new mongoose.Schema({
    title: { type: String, required: [true, 'Вакансия должна иметь название'] },
    description: { type: String, required: [true, 'Введите описание вакансии'] },
    required_skills: { type: String, required: [true, 'Перечислите ключевые навыки, через запятую'] },
    archived: { type: Boolean },

    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

VacancySchema.index({'$**': 'text'});

VacancySchema.methods.toJSON = function() {
    return {
        title: this.title,
        description: this.description,
        required_skills: this.required_skills,
        archived: this.archived
    };
}

mongoose.model('Vacancy', VacancySchema);