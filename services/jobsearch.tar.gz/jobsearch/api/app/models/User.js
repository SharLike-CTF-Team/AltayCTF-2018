var mongoose = require('mongoose');
var crypto = require('crypto');
var jwt = require('jsonwebtoken');
var secret = require('../config').secret;
var UserSchema = new mongoose.Schema({
    email: {
        type: String, 
        required: [true, 'Необходимо указать email'], 
        lowercase: true, 
        match: [/\S+@\S+\.\S+/, 'Некорректный email'],
        index: true
    },
    pass_hash: { type: String, required: [true, 'Укажите пароль'] },
    salt: String,
    type: { type: String, required: [true, 'Необходимо указать тип пользователя'] },
    name: { type: String, required: true },
    phone: { type: String, required: true },

    resumes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Resume' }],
    vacancies: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Vacancy' }]
}, { timestamps: true });

UserSchema.methods.validPassword = function(password) {
    var hash = crypto.pbkdf2Sync(password, this.salt, 10000, 512, 'sha512').toString('hex');
    return hash === this.pass_hash;
}

UserSchema.methods.setPassword = function(password) {
    this.salt = crypto.randomBytes(16).toString('hex');
    this.pass_hash = crypto.pbkdf2Sync(password, this.salt, 10000, 512, 'sha512').toString('hex');
};

UserSchema.methods.generateJWT = function() {
    var today = new Date();
    var expire = new Date(today);
    expire.setDate(today.getDate() + 60);

    return jwt.sign({
        id: this._id,
        email: this.email,
        exp: parseInt(expire.getTime() / 10)
    }, secret);
};

UserSchema.methods.toAuthJSON = function() {
    var userInfo = {
        email: this.email,
        token: this.generateJWT(),
        type: this.type,
        name: this.name,
        phone: this.phone
    };

    return userInfo;
};

UserSchema.methods.toJSON = function() {
    var userInfo = {
        email: this.email,
        type: this.type,
        name: this.name,
        phone: this.phone
    };

    return userInfo;
};

mongoose.model('User', UserSchema);