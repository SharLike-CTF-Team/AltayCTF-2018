var mongoose = require('mongoose');

var ResumeSchema = new mongoose.Schema({
    position: { type: String, required: [true, 'Укажите желаемую должность'] },
    salary: Number,
    experience: { type: String, required: [true, 'Перечислите места, где вы работали и чем занимались'] },
    skills: { type: String, required: [true, 'Перечислите ключевые навыки, через запятую'] },
    education: { type: String, required: [true, 'Укажите, где вы получали образование'] },
    about_me: { type: String, required: [true, 'Расскажите о себе: хобби, личностные качества, любая дополнительная информация'] },
    access: {type: String, required: true},

    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
});

ResumeSchema.index({'$**': 'text'});

ResumeSchema.method.toJSON = function() {
    return {
        position: this.position,
        salary: this.salary,
        experience: this.experience,
        skills: this.skills,
        education: this.education,
        about_me: this.about_me
    }
}

mongoose.model('Resume', ResumeSchema);