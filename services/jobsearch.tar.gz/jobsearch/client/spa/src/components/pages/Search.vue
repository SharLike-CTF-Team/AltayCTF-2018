<template>
  <div class="c-wrapper">
    <myHeader></myHeader>
    <myFooter></myFooter>
  </div>
</template>

<script>
import Authentication from '@/components/pages/Authentication'
import myHeader from '@/components/partials/Header'
import myFooter from '@/components/partials/Footer'
export default {
  data () {
    return {}
  },
  components: {
    myHeader,
    myFooter
  },
  methods: {
    isAuth () {
      return Authentication.checkAuthentication()
    }
  }
}
</script>

<style>

</style>
