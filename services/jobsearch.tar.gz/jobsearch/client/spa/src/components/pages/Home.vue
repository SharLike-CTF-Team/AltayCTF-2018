<template>
  <div class="c-wrapper">
    <myHeader></myHeader>

    <v-jumbotron color="grey lighten-5" height="300px">
      <v-container fill-height>
        <v-layout align-center>
          <v-flex>
            <h3 class="display-2">Работа найдется для каждого</h3>
            <v-divider class="my-3"></v-divider>
            <div class="title mb-3">14888 вакансий</div>
            <div class="title mb-3">7675 резюме</div>
            <div class="title mb-3">228 компаний</div>
            <router-link to="/profile">
              <v-btn large color="warning" class="mx-0">Опубликовать резюме</v-btn>
            </router-link>
            <router-link to="/profile">
              <v-btn large color="warning" class="mx-0">Разместить вакансию</v-btn>
            </router-link>
          </v-flex>
        </v-layout>
      </v-container>
    </v-jumbotron>

    <v-layout row>
      <v-flex xs3 order-md1 order-xs3>
        <v-data-table
          :headers="companies_headers"
          :items="companies"
          hide-actions
          class="elevation-1"
        >
          <template slot="items" slot-scope="props">
            <td>{{ props.item.name }}</td>
            <td class="text-xs-right">{{ props.item.count }}</td>
          </template>
        </v-data-table>
      </v-flex>

      <v-flex xs5 order-md1 order-xs3>
        <v-data-table
          :headers="vacancies_headers"
          :items="vacancies"
          hide-actions
          class="elevation-1"
        >
          <template slot="items" slot-scope="props">
            <td>{{ props.item.name }}</td>
            <td>{{ props.item.price }}</td>
            <td>{{ props.item.company }}</td>
          </template>
        </v-data-table>
      </v-flex>

      <v-flex xs4 order-md1 order-xs3>
        <v-data-table
          :headers="resumes_headers"
          :items="resumes"
          hide-actions
          class="elevation-1"
        >
          <template slot="items" slot-scope="props">
            <td>{{ props.item.position }}</td>
            <td>{{ props.item.salary }} руб.</td>
          </template>
        </v-data-table>
      </v-flex>
    </v-layout>

    <myFooter></myFooter>
  </div>
</template>
<script>
import Authentication from '@/components/pages/Authentication'
import myHeader from '@/components/partials/Header'
import myFooter from '@/components/partials/Footer'
import Axios from 'axios'

const API = `http://${window.location.hostname}:3000`
export default {
  data () {
    return {
      companies_headers: [
        {
          text: 'Топ компаний',
          align: 'left',
          sortable: false,
          value: 'name'
        },
        { text: '', align: 'right', value: 'count', sortable: false }
      ],
      companies: [
        {
          name: 'Positive Technologies',
          count: 230
        },
        {
          name: 'Group-IB',
          count: 170
        },
        {
          name: 'Wallarm',
          count: 100
        },
        {
          name: 'СКБ Контур',
          count: 80
        },
        {
          name: 'Wrike',
          count: 70
        },
        {
          name: 'Forex Club',
          count: 100
        }
      ],
      vacancies_headers: [
        {
          text: 'Последние вакансии',
          align: 'left',
          sortable: false,
          value: 'name'
        },
        { text: '', align: 'right', value: 'price', sortable: false },
        { text: '', align: 'right', value: 'company', sortable: false }
      ],
      vacancies: [
        {
          name: 'Ведущий инженер-программист',
          price: 'от 25 000 руб.',
          company: 'ООО "БТП"'
        },
        {
          name: 'Прораб',
          price: 'от 15 000 руб.',
          company: 'Жилищная инициатива'
        },
        {
          name: 'Хакер',
          price: 'сдельная',
          company: 'ФСБ'
        }
      ],
      resumes_headers: [
        {
          text: 'Резюме соискателей',
          align: 'left',
          sortable: false,
          value: 'name'
        },
        { text: '', align: 'right', value: 'position', sortable: false }
      ],
      resumes: []
    }
  },
  components: {
    myHeader,
    myFooter
  },
  methods: {
    loadResumes () {
      Axios.post(`${API}/api/resumes/list`, {access: 'free'}).then(result => {
        let data = result.data.data
        if (data === undefined) {
          return
        }
        for (let resume of data) {
          this.resumes.push({
            position: resume.position,
            salary: resume.salary
          })
        }
      })
    },
    isAuth () {
      return Authentication.checkAuthentication()
    }
  },
  mounted () {
    this.loadResumes()
  }
}
</script>
