<template>
  <div>
    <div class="c-wrapper">
      <myHeader></myHeader>
      <div class="l-profile-container">
        <div v-if="this.user.type == 'employer'" class="l-profile">
          <h1 align="center" class="title">Разместить вакансию</h1>
          <v-form>
            <v-text-field label="Введите наименование вакансии"
                          v-model="vacancy.title"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-text-field label="Введите описание вакансии"
                          v-model="vacancy.description"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-text-field label="Введите требуемые навыки"
                          v-model="vacancy.skills"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-btn block color="warning" @click.native="submitVacancy()">Создать</v-btn>
          </v-form>
        </div>

        <div v-if="this.user.type == 'applicant'" class="l-profile">
          <h1 align="center" class="title">Опубликовать резюме</h1>
          <v-form>
            <v-text-field label="Укажите желаемую должность"
                          v-model="resume.position"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-text-field label="Введите желаемую зарплату"
                          v-model="resume.salary"
                          :rules="rules"
                          color="white">
            </v-text-field>
            <v-text-field label="Укажите Ваши навыки"
                          v-model="resume.skills"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-text-field label="Какой ваш опыт работы?"
                          v-model="resume.experience"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-text-field label="Укажите, где получали образование"
                          v-model="resume.education"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-text-field label="Расскажите о себе"
                          v-model="resume.about_me"
                          :rules="rules"
                          required
                          color="white">
            </v-text-field>
            <v-btn block color="warning" @click.native="submitResume()">Создать</v-btn>
          </v-form>
        </div>

        <div v-if="this.user.type == 'employer'">
          <h1 align="center" class="title">Мои вакансии</h1>
          <v-data-table
            :headers="vacancies_headers"
            :items="vacancies"
            hide-actions
            class="elevation-1"
          >
            <template slot="items" slot-scope="props">
              <td>{{ props.item.title }}</td>
              <td>{{ props.item.description }}</td>
              <td>{{ props.item.required_skills }}</td>
            </template>
          </v-data-table>
        </div>

        <div v-if="this.user.type == 'applicant'">
          <h1 align="center" class="title">Мои резюме</h1>
          <v-data-table
            :headers="resumes_headers"
            :items="resumes"
            hide-actions
            class="elevation-1"
          >
            <template slot="items" slot-scope="props">
              <td>{{ props.item.position }}</td>
              <td>{{ props.item.salary }} руб.</td>
              <td>{{ props.item.experience }}</td>
              <td>{{ props.item.skills }}</td>
              <td>{{ props.item.education }}</td>
              <td>{{ props.item.about_me }}</td>
            </template>
          </v-data-table>
        </div>

        <v-snackbar timeout="6000"
                    bottom="bottom"
                    color="green lighten-1"
                    v-model="snackbar_success">
        {{ message_success }}
        </v-snackbar>

        <v-snackbar timeout="6000"
                    bottom="bottom"
                    color="red lighten-1"
                    v-model="snackbar_error">
        {{ message_error }}
        </v-snackbar>
      </div>
    </div>
    <myFooter></myFooter>
  </div>
</template>

<script>
import Authentication from '@/components/pages/Authentication'
import myHeader from '@/components/partials/Header'
import myFooter from '@/components/partials/Footer'
import Axios from 'axios'

const API = `http://${window.location.hostname}:3000`
export default {
  data () {
    return {
      showResumeForm: false,
      showVacancyForm: false,
      user: {},
      rules: [(value) => !!value || 'Необходимо заполнить поле'],
      vacancy: {
        title: '',
        description: '',
        skills: ''
      },
      resume: {
        position: '',
        salary: '',
        skills: '',
        experience: '',
        education: '',
        about_me: '',
        access: 'free'
      },
      snackbar_success: false,
      snackbar_error: false,
      message_success: '',
      message_error: '',
      vacancies_headers: [
        { text: 'Название', align: 'left', sortable: false, value: 'title' },
        { text: 'Описание', align: 'left', value: 'description', sortable: false },
        { text: 'Требуемые навыки', align: 'left', value: 'required_skills', sortable: false }
      ],
      vacancies: [],
      resumes_headers: [
        { text: 'Желаемая должность', align: 'left', sortable: false, value: 'name' },
        { text: 'Желаемая З/П', align: 'left', value: 'position', sortable: false },
        { text: 'Опыт работы', align: 'left', value: 'position', sortable: false },
        { text: 'Навыки', align: 'left', value: 'position', sortable: false },
        { text: 'Образование', align: 'left', value: 'position', sortable: false },
        { text: 'О себе', align: 'left', value: 'position', sortable: false }
      ],
      resumes: []
    }
  },
  components: {
    myHeader,
    myFooter
  },
  methods: {
    isAuth () {
      return Authentication.checkAuthentication()
    },

    loadUserInfo () {
      Axios.get(`${API}/api/user`, {
        headers: { 'Authorization': Authentication.getAuthenticationHeader(this) }
      }).then(({data}) => {
        this.user = data.user
        if (this.user.type === 'employer') {
          this.loadMyVacancies()
        } else {
          this.loadMyResumes()
        }
      })
    },

    submitVacancy () {
      if (this.vacancy.title === '' || this.vacancy.description === '' || this.vacancy.skills === '') {
        this.snackbar_error = true
        this.message_error = 'Не все поля заполнены'
        return false
      }
      Axios.put(`${API}/api/vacancies/create`, this.vacancy, {
        headers: { 'Authorization': Authentication.getAuthenticationHeader(this) }
      }).then(({data}) => {
        if (data.success) {
          this.snackbar_success = true
          this.message_success = data.message
          this.loadMyVacancies()
        } else {
          this.snackbar_error = true
          this.message_error = data.message
        }
      })
    },

    submitResume () {
      if (this.resume.position === '' ||
          this.resume.skills === '' ||
          this.resume.experience === '' ||
          this.resume.education === '' ||
          this.resume.about_me === ''
      ) {
        this.snackbar_error = true
        this.message_error = 'Не все поля заполнены'
        return false
      }

      Axios.put(`${API}/api/resumes/create`, this.resume, {
        headers: { 'Authorization': Authentication.getAuthenticationHeader(this) }
      }).then(({data}) => {
        if (data.success) {
          this.snackbar_success = true
          this.message_success = data.message
          this.loadMyResumes()
        } else {
          this.snackbar_error = true
          this.message_error = data.message
        }
      })
    },

    loadMyVacancies () {
      Axios.get(`${API}/api/vacancies/list/my`, {
        headers: { 'Authorization': Authentication.getAuthenticationHeader(this) }
      }).then(({data}) => {
        this.vacancies = data.data
      })
    },

    loadMyResumes () {
      Axios.get(`${API}/api/resumes/list/my`, {
        headers: { 'Authorization': Authentication.getAuthenticationHeader(this) }
      }).then(({data}) => {
        this.resumes = data.data
      })
    }
  },
  mounted () {
    this.loadUserInfo()
  }
}
</script>

<style lang="scss">
  @import "./../../assets/styles";
  .l-profile-container {
    background-color: $background-color;
    padding: 15px;
  }
  .l-profile {
    margin: 0 auto;
    max-width: 500px;
  }
  h1 {
    margin: 25px 0;
  }
</style>
