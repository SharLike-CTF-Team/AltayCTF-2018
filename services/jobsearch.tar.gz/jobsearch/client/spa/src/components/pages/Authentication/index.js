import Axios from 'axios'
import router from '@/router'
// TODO: вынести в конфиг
const API = `http://${window.location.hostname}:3000`

export default {
  user: { authenticated: false },
  userInfo: {},

  authenticate (context, credentials, redirect) {
    if (credentials.user.email === '' || credentials.user.password === '') {
      context.snackbar = true
      context.message = 'Не все поля заполнены'
      return false
    }
    Axios.post(`${API}/api/signin`, credentials)
      .then(response => {
        context.$cookie.set('token', response.data.user.token, '1D')
        context.validLogin = true
        this.user.authenticated = true

        if (redirect) {
          router.push(redirect)
        }
      })
      .catch(error => {
        let response = error.response
        context.snackbar = true
        context.message = response.data.message
      })
  },

  signup (context, credentials, redirect) {
    if (credentials.user.email === '' || credentials.user.password === '' || credentials.user.type === '' || credentials.user.name === '' || credentials.user.phone === '') {
      context.snackbar = true
      context.message = 'Не все поля заполнены'
      return false
    }
    Axios.put(`${API}/api/signup`, credentials)
      .then(response => {
        if (response.data.success) {
          if (redirect) {
            router.push(redirect)
          }
        } else {
          context.snackbar = true
          context.message = response.data.message
        }
      })
      .catch(({response: {data}}) => {
        context.snackbar = true
        context.message = data.message
      })
  },

  signout (context, redirect) {
    context.$cookie.delete('token')
    this.user.authenticated = false

    if (redirect) {
      router.push(redirect)
    }
  },

  checkAuthentication () {
    const token = document.cookie
    if (token) {
      return true
    }
    return false
  },

  getAuthenticationHeader (context) {
    return `Bearer ${context.$cookie.get('token')}`
  }
}
