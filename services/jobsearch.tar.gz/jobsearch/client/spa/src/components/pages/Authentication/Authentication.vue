<template>
  <div class="l-auth-container">
    <div class="l-auth" v-if="loginVisible">
      <h1 class="title">Войти</h1>
      <v-form v-model="validLogin">
        <v-text-field label="Ваш E-mail"
                      v-model="credentials.user.email"
                      prepend-icon="email"
                      :rules="rules"
                      required
                      color="white">
        </v-text-field>

        <v-text-field label="Ваш пароль"
                      v-model="credentials.user.password"
                      prepend-icon="lock"
                      :rules="rules"
                      :append-icon="loginPasswordVisible ? 'visibility': 'visibility_off'"
                      :append-icon-cb="() => (loginPasswordVisible = !loginPasswordVisible)"
                      :type="loginPasswordVisible ? 'text' : 'password'"
                      color="white"
                      required
                      >
        </v-text-field>

        <v-btn block color="warning" @click.native="submitAuthentication()">Авторизоваться</v-btn>
        <v-btn flat block color="white" @click.native="loginVisible = false; signUpVisible = true">Регистрация</v-btn>
      </v-form>
    </div>

    <div class="l-signup" v-if="signUpVisible">
      <h1 class="title">Регистрация</h1>
      <v-form v-model="validSignUp">
        <v-text-field label="Ваш E-mail"
                      v-model="newUser.user.email"
                      prepend-icon="email"
                      :rules="rules"
                      required
                      color="white">
        </v-text-field>

        <v-text-field label="Ваш пароль"
                      v-model="newUser.user.password"
                      prepend-icon="lock"
                      :rules="rules"
                      :append-icon="signUpPasswordVisible ? 'visibility': 'visibility_off'"
                      :append-icon-cb="() => (signUpPasswordVisible = !signUpPasswordVisible)"
                      :type="signUpPasswordVisible ? 'text' : 'password'"
                      color="white"
                      required
                      >
        </v-text-field>

        <v-radio-group v-model="newUser.user.type" :mandatory="false">
          <v-radio  label="Соискатель"
                    value="applicant"
                    color="white"
                    @click.native="isApplicant = true; isEmployer = false">
          </v-radio>
          <v-radio  label="Работодатель"
                    value="employer"
                    color="white"
                    @click.native="isApplicant = false; isEmployer = true">
          </v-radio>
        </v-radio-group>

        <div v-if="isApplicant">
          <v-text-field label="Ваше имя"
                      v-model="newUser.user.name"
                      prepend-icon="account_box"
                      :rules="rules"
                      required
                      color="white">
          </v-text-field>

          <v-text-field label="Укажите номер телефона"
                      v-model="newUser.user.phone"
                      prepend-icon="phone"
                      :rules="rules"
                      required
                      color="white">
          </v-text-field>
        </div>
        <div v-if="isEmployer">
          <v-text-field label="Наименование организации"
                      v-model="newUser.user.name"
                      prepend-icon="work"
                      :rules="rules"
                      required
                      color="white">
          </v-text-field>
          <v-text-field label="Укажите контактный номер"
                      v-model="newUser.user.phone"
                      prepend-icon="phone"
                      :rules="rules"
                      required
                      color="white">
          </v-text-field>
        </div>

        <v-btn block color="warning"  @click.native="submitSignUp()">Зарегистрироваться</v-btn>
        <v-btn flat block color="white" @click.native="loginVisible = true; signUpVisible = false">Войти</v-btn>
      </v-form>
    </div>

    <v-snackbar timeout="6000"
                bottom="bottom"
                color="red lighten-1"
                v-model="snackbar">
      {{ message }}
    </v-snackbar>
  </div>
</template>
<script>
import Authentication from '@/components/pages/Authentication'
export default {
  data () {
    return {
      snackbar: false,
      validLogin: false,
      validSignUp: false,
      loginVisible: true,
      signUpVisible: false,
      loginPasswordVisible: false,
      signUpPasswordVisible: false,
      rules: [(value) => !!value || 'Необходимо заполнить поле'],
      credentials: {
        user: {
          email: '',
          password: ''
        }
      },
      newUser: {
        user: {
          email: '',
          password: '',
          type: '',
          name: '',
          phone: ''
        }
      },
      isApplicant: false,
      isEmployer: false,
      message: ''
    }
  },
  methods: {
    submitAuthentication () {
      Authentication.authenticate(this, this.credentials, '/')
    },

    submitSignUp () {
      Authentication.signup(this, this.newUser, '/')
    }
  }
}
</script>
<style lang="scss">
  @import "./../../../assets/styles";
  .l-auth {
    background-color: $background-color;
    padding: 15px;
    margin: 45px auto;
    min-width: 272px;
    max-width: 420px;
    animation: bounceIn 1s forwards ease;
  }
  .l-signup {
    background-color: $background-color;
    padding: 15px;
    margin: 45px auto;
    min-width: 272px;
    max-width: 420px;
    animation: slideInFromLeft 1s forwards ease;
  }
  .title {
    text-align: center;
    color: white;
  }
</style>
