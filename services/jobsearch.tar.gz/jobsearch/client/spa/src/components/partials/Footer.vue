<template>
  <v-footer height="auto" dark>
    <v-layout row wrap justify-center>
      <v-flex xs12 py-3 text-xs-center>
        &copy;2018 — <strong>JobSearch</strong>
      </v-flex>
    </v-layout>
  </v-footer>
</template>
<script>
export default {
  name: 'myFooter',
  inherit: true
}
</script>
