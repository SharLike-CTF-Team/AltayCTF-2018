<template>
  <div>
    <v-card flat>
      <v-container fluid>
        <v-layout row child-flex wrap>
          <div>
            <v-toolbar dark>
              <v-toolbar-title class="white--text">
                <router-link to="/">
                  JobSearch - найти работу просто!
                </router-link>
              </v-toolbar-title>
              <v-spacer></v-spacer>
              <v-text-field v-model="search.query" prepend-icon="search" hide-details single-line placeholder="Я ищу..."></v-text-field>
              <v-select
                :items="items"
                v-model="search.type"
                item-text="type_ru"
                item-value="type"
                label="Вакансии"
                single-line
                hide-selected
                hide-details
              ></v-select>
              <v-btn color="warning" @click.native="submitSearch()">Найти</v-btn>

              <router-link v-if="isAuth()" to="/profile">
                <v-btn flat>Личный кабинет</v-btn>
                <v-btn @click.native="submitSignout()" flat>Выйти</v-btn>
              </router-link>
              <router-link v-else to="/auth">
                <v-btn flat>Авторизация</v-btn>
              </router-link>

            </v-toolbar>
          </div>
        </v-layout>
      </v-container>
    </v-card>

    <v-card v-if="this.$route.path === '/search'">
      <v-list two-line>
        <template v-for="(item, index) in searchItems">
          <v-subheader v-if="item.header" :key="item.header">{{ item.header }}</v-subheader>
          <v-divider v-else-if="item.divider" :inset="item.inset" :key="index"></v-divider>
          <v-list-tile v-else :key="index">
            <v-list-tile-content>
              <v-list-tile-title v-html="item.title"></v-list-tile-title>
              <v-list-tile-sub-title v-html="item.description"></v-list-tile-sub-title>
            </v-list-tile-content>
          </v-list-tile>
        </template>
      </v-list>
    </v-card>
  </div>
</template>
<script>
import Authentication from '@/components/pages/Authentication'
import router from '@/router'
import Axios from 'axios'

const API = `http://${window.location.hostname}:3000`
export default {
  name: 'myHeader',
  inherit: true,
  data () {
    return {
      search: {
        query: this.$route.query.query ? this.$route.query.query : '',
        type: this.$route.query.type ? this.$route.query.type : 'vacancies',
        archived: false
      },
      items: [
        { type_ru: 'Вакансии', type: 'vacancies' },
        { type_ru: 'Резюме', type: 'resumes' }
      ],
      searchItems: [
        { header: 'Результаты поиска' }
      ]
    }
  },
  methods: {
    submitSearch () {
      router.push({
        name: 'Search',
        query: {
          query: this.search.query,
          type: this.search.type
        }
      })
      if (!('query' in this.$route.query) || !('type' in this.$route.query)) {
        router.push({ name: 'Home' })
      }

      this.searchItems = [
        { header: 'Результаты поиска' }
      ]
      Axios.post(`${API}/api/search`, {query: this.$route.query.query, type: this.$route.query.type, archived: false})
        .then(result => {
          let data = result.data.data
          if (data === undefined) {
            this.searchItems = [
              { header: 'Результаты поиска' }
            ]
            return
          }
          if (this.$route.query.type === 'vacancies') {
            for (let searchResult of data) {
              this.searchItems.push({
                title: searchResult.title,
                description: searchResult.description
              })
              this.searchItems.push({ divider: true, inset: true })
            }
          } else {
            for (let searchResult of data) {
              this.searchItems.push({
                title: searchResult.position,
                description: searchResult.experience
              })
              this.searchItems.push({ divider: true, inset: true })
            }
          }
        })
        // .catch(err => {

        // })
    },
    isAuth () {
      return Authentication.checkAuthentication()
    },
    submitSignout () {
      Authentication.signout(this, '/')
    }
  },
  mounted () {
    if (this.$route.path === '/search') {
      this.submitSearch()
    }
  }
}
</script>
