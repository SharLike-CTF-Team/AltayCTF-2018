import Vue from 'vue'
import Router from 'vue-router'
// pages
import * as Auth from '@/components/pages/Authentication'
import Home from '@/components/pages/Home'
import Search from '@/components/pages/Search'
import Profile from '@/components/pages/Profile'
import Authentication from '@/components/pages/Authentication/Authentication'
Vue.use(Router)
const router = new Router({
  routes: [
    {
      path: '/auth',
      name: 'Authentication',
      component: Authentication
    },
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/search',
      name: 'Search',
      component: Search
    },
    {
      path: '/profile',
      name: 'Profile',
      meta: {
        requiredAuth: true
      },
      component: Profile
    }
  ]
})
router.beforeEach((to, from, next) => {
  if (to.meta.requiredAuth) {
    if (Auth.default.checkAuthentication()) {
      next()
    } else {
      router.push('/auth')
    }
  } else {
    next()
  }
})
export default router
