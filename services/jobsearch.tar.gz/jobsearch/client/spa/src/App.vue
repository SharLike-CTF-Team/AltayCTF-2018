<template>
  <div id="app">
    <v-app dark>
      <router-view/>
    </v-app>
  </div>
</template>
<script>
export default {
  name: 'app'
}
</script>
<style lang="scss">
  @import "./assets/styles";
  .application.theme--dark {
    background: url('./assets/images/bg-1.jpg') !important;
    background-size: cover !important;
  }
  .card .container.fluid {
    padding: 0 !important;
  }
  .theme--dark .card {
    background: none !important;
  }
  .theme--dark .toolbar,
  .theme--dark .table {
    background: $background-color !important;
  }
  .c-wrapper {
    width: 85%;
    margin: 0 auto;
    min-height: 90vh;
  }
  .jumbotron__background.grey.lighten-5 {
    background-color: rgba(250, 250, 250, .8) !important;
  }
  .jumbotron__content {
    color: black !important;
  }
  .layout.row {
    padding: 16px 0 !important;
  }
  .theme--dark .table thead th {
    font-size: 16px;
  }
  .table.table tbody td {
    font-size: 14px;
  }
  .footer.grey.lighten-5 {
    background-color: rgba(250, 250, 250, .8) !important;
    color: black !important;
  }
  a {
    color: #fff !important;
    text-decoration: none;
  }
</style>
