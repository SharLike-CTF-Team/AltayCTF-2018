from flask import render_template, session, request, url_for, redirect
from app import app, mysql

import hashlib
import random
import string
import datetime
import pyqrcode


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        login = request.form.get('login')
        time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        about = request.form.get('about')
        password = gen(time, 10)
        hash = hashlib.md5(password.encode('utf-8')).hexdigest()

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT id FROM {}.users ORDER BY id DESC LIMIT 1".format(app.config['MYSQL_DB']))
        data = cursor.fetchall()
        if data:
            qrname = int(data[0][0])+1
        else:
            qrname = 1

        qr = pyqrcode.create(', '.join((login, email, about, time)),encoding='utf8')
        qr.png('app/static/{}.png'.format(qrname),scale=2, quiet_zone=1)

        query = "INSERT INTO {}.users (name, email, password, about, time) VALUES (%s, %s, %s, %s, %s)".format(app.config['MYSQL_DB'])
        cursor.execute(query, (login, email, hash, about, time))
        mysql.connection.commit()

        return render_template('password.html', password=password, uid=qrname)
    return render_template('register.html')


@app.route('/')
def index():
    if 'username' not in session:
        session['username'] = None

    cursor = mysql.connection.cursor()
    query = '''CREATE TABLE IF NOT EXISTS `users` (`id` int(11) NOT NULL AUTO_INCREMENT,`name` varchar(255) \
    NOT NULL DEFAULT '',`email` varchar(255) NOT NULL DEFAULT '',`password` varchar(255) NOT NULL DEFAULT '',\
    `about` varchar(255) NOT NULL DEFAULT '',`time` varchar(255) NOT NULL DEFAULT '',PRIMARY KEY (`id`)) \
    DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_unicode_ci;'''
    cursor.execute(query)
    query2 = '''CREATE TABLE IF NOT EXISTS `chat` (`id` int(11) NOT NULL AUTO_INCREMENT,`text` varchar(255) \
    NOT NULL DEFAULT '',`author` varchar(255) NOT NULL DEFAULT '',PRIMARY KEY (`id`)) \
    DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_unicode_ci;'''
    cursor.execute(query2)
    mysql.connection.commit()

    return render_template('index.html')


@app.route('/user/<int:userid>')
def profile(userid):
    cursor = mysql.connection.cursor()
    query = "SELECT * FROM {}.users WHERE id=%s".format(app.config['MYSQL_DB'])
    cursor.execute(query, (str(userid),))
    data = cursor.fetchall()
    if data:
        name = data[0][1]
        email = data[0][2]
        about = data[0][4]
        time = data[0][5]
        return render_template('profile.html', uid=str(userid), name=name, email=email,about=about,time=time)
    return '404'


@app.route('/chat')
def chat():
    if session['username']:
        cursor = mysql.connection.cursor()
        query = "SELECT text, author FROM {}.chat".format(app.config['MYSQL_DB'])
        cursor.execute(query)
        data = cursor.fetchall()
        msgs = [[i[0], i[1]] for i in data if i][::-1]
        return render_template('chat.html', uname=session['username'], messages=msgs)
    return 'You are not logged in'


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('login')
        password = request.form.get('pass')
        hash = hashlib.md5(password.encode('utf-8')).hexdigest()
        cursor = mysql.connection.cursor()
        query = "SELECT * from {}.users WHERE name=%s and password=%s".format(app.config['MYSQL_DB'])
        cursor.execute(query, (username, hash))
        data = cursor.fetchall()
        if data:
            session['username'] = username
            return redirect('/chat', 302)
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/')


def gen(t, len=10):
    possible = string.ascii_letters + string.digits
    return ''.join([str(random.choice(possible, t)) for i in range(len)])


if __name__ == '__main__':
    app.run(debug=True)