class Config(object):
	"""
	Configuration base, for all environments.
	"""
	SECRET_KEY = 'nuttertools'
	MYSQL_USER = 'pred_user'
	MYSQL_PASSWORD = 'secret_pass'
	MYSQL_DB = 'service'
	MYSQL_HOST = 'mysql'
	MYSQL_CHARSET = 'utf8'
	STATIC_FOLDER = 'static'

class DevelopmentConfig(Config):
	DEBUG = True
