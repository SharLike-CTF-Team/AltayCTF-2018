
from flask_socketio import emit, join_room
from socketio_app import app, socketio, mysql

import sys

#  Append project paths to sys.path
#sys.path = ['/virtual','/virtual/lib/python3.5','/virtual/lib/python3.5/site-packages',
#'/virtual','/usr/local/bin','/usr/local/lib/python3.5/dist-packages','/usr/lib/python3/dist-packages']


@socketio.on('message', namespace='/chat')
def chat_message(message):
    cursor = mysql.connection.cursor()
    msg = message['data']['message']
    try:
        print(message)
    except UnicodeEncodeError:
        print("can't decode an incoming message")
    author = message['data']['author']
    query = "INSERT INTO {}.chat (text, author) VALUES (%s, %s)".format(app.config['MYSQL_DB'])
    cursor.execute(query, (msg, author))
    mysql.connection.commit()
    emit('message', {'data': message['data']}, broadcast=True)


@socketio.on('connect', namespace='/chat')
def test_connect():
    emit('my response', {'data': 'Connected', 'count': 0})


if __name__ == '__main__':
    socketio.run(app)
