from gevent import monkey
monkey.patch_all()

from flask import Flask
from flask_socketio import SocketIO
from flask_mysqldb import MySQL

app = Flask(__name__)
socketio = SocketIO(app)
mysql = MySQL()

app.config.from_object('app.configuration.DevelopmentConfig')

mysql.init_app(app)

from socketio_app import socketio_worker
